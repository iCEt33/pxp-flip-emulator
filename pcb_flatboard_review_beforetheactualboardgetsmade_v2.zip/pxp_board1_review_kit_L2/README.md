# PxP board 1 — review kit (schematic B1-0.7, layout L2, 12 November 2026, second issue)

Board 1 of a DIY flip phone: a "flat test phone", 145 × 100 mm, 4 layers, with every chip of the phone on one
board plus test points. ESP32-S3-WROOM-1-N16R8, SIMCom A7670G (LTE Cat-1), BQ25896 charger, MAX17048 gauge,
ES8311 codec, TCA8418 keypad chip, PCA9535 expander, PCF85063A clock, TFT / OLED / camera on ribbons, microSD,
USB-C. The 23 keys are bare dome pads on the back, at the phone's key positions; both screens hang past the
edge above them and face the key side.

This kit answers the third review. **Start with `REVIEW3_ANSWERS.md`**: each finding, what was done, what was not,
and two things that turned up on the way. (It replaces the kit of earlier the same day, which had schematic
B1-0.6; what is new since then is the last section of `NOTES_L2.md`.)

## What is in here

| | |
|---|---|
| `REVIEW3_ANSWERS.md` | review 3, point by point |
| `NOTES_L2.md` | everything that changed since review 3, with numbers, rules and known limits |
| `SLEEP_BUDGET.md` | the sleep-current budget review 3 asked for: one line per part, what firmware must do, how to measure |
| `01_…png` to `17_…png` | pictures: the board from both sides, the four copper layers, the eight schematic pages, the assembly drawing, and how the TFT and OLED ribbons sit in their connectors |
| `pxp_board1_schematic_B1-0.7.pdf` | the schematic as one PDF (the same pages as pictures 07 to 14) |
| `kicad/pxp_board1/` | the KiCad project: open `pxp_board1.kicad_pro` (made in KiCad 7, opens in 8 and 9). Schematic and board are in one project, so cross-probing works |
| `netlist/pxp_board1.net` | KiCad's netlist export of the schematic, for reading pin by pin |
| `gerbers/` | Gerber files, drill files, drill maps and the job file |
| `assembly/` | BOM (fitted parts with part numbers) and the pick-and-place file |
| `FAB_NOTES.md` | what the board maker is told: stack-up, finish, holes, assembly notes |

## Checked on exactly these files

- KiCad's rule check, zones refilled: **0 errors, 0 unconnected**, against maker-level minimums in Board Setup
  (0.15 mm track and gap, 0.15 mm via ring, 0.6 mm via, 0.3 mm hole, 0.3 mm hole to hole) and the project's
  rule file (0.25 mm copper to hole, 0.2 mm track to plated component pad, 0.33 mm track to plated hole).
- Board against schematic: every pad carries the net the schematic gives it (435 parts, 1,272 pins); values,
  footprint names, field texts and the 15 not-fitted parts agree on both.
- No via in a soldered pad or within 0.15 mm of one (1,471 vias). No filled or capped vias. The same holds for
  stencil openings: the modem's are 0.5 mm longer than its lands, and no via or foreign track lies under them.
- **Layer 3 carries no track**: both inner layers are unbroken ground.
- **No signal track on the top layer under the ESP32 module or under the modem.**
- No loop and no dead-end branch (of 1.5 mm or more) in any signal net; no joint narrower than the smallest
  track.
- Schematic: 1,018 automatic checks (pin map end to end, bus addresses, supply pins, regulator voltages from
  the fitted resistors), 0 failed.

## Still open

1. **Camera ribbon (J701).** Pin order not yet checked against a module (it varies between sellers).
2. **Ribbons in general:** the TFT's and the OLED's contact face and pin-1 end were read from the makers'
   drawings, not from parts in hand. Each ribbon's pin 1 gets one look against the "1" printed on the board
   before the first plug-in.
3. **Modem sleep current:** SIMCom's guides give "TBD", so the standby figure in `SLEEP_BUDGET.md` has a
   gap until it is measured.
4. Smaller ones: the keypad chip's capacitor is 3 mm from its pin; USB D+ changes layer twice more than D−;
   the earpiece and microphone pairs were laid by the router, not drawn by hand.

Schematic and layout were made with Claude (Anthropic's AI), using its own generator, placement and routing
scripts, and then checked in KiCad. Comments are very welcome.
