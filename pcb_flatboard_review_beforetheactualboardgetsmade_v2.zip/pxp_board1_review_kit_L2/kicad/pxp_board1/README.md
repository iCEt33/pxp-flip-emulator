# PxP board 1 — KiCad project (schematic B1-0.7, layout L2, 12 November 2026)

**Open `pxp_board1.kicad_pro`** in KiCad 7, 8 or 9 (made in KiCad 7.0; newer versions convert on save).
Schematic and board are in the same project, so cross-probing works.

| File | What |
|---|---|
| `pxp_board1.kicad_sch` + 7 sheets | schematic, 8 pages (overview, power, MCU, modem, audio, keypad / IO, displays, camera); part numbers are in the symbol fields |
| `pxp_board1.kicad_pcb` | the board: 4 layers, 1.6 mm. L1 signals + ground pour · L2 solid ground · L3 solid ground · L4 signals + ground pour and the key pads. The maker's 7628 stack-up (0.2 mm prepreg) is entered in Board Setup |
| `pxp_board1.kicad_dru` | the project's rules: hole and plated-pad clearances, the antenna line's pour gap, two footprint exceptions |
| `pxp.kicad_sym`, `pxp.pretty/` | own symbols and footprints, drawn from the makers' data sheets. `VSSOP-10_3x3mm_P0.5mm` is an unchanged copy of KiCad 7's footprint (KiCad library licence: CC-BY-SA 4.0 with its exception for designs) |

Board Setup holds maker-level minimums (0.15 mm track and gap, 0.15 mm via ring, 0.6 mm via, 0.3 mm hole,
0.3 mm hole to hole). The rule check gives 0 errors and 0 unconnected with zones refilled.

On the board, the numbers printed at the two ends of J601 (45 and 1) are the TFT's pin numbers:
pad *n* of J601 carries display pin *46 − n*. J602 (OLED) is straight: pad *n* carries display pin *n*, and
the "1" printed beside it marks pad 1. All three ribbon connectors take contacts on either face.

What changed, the numbers and the known limits are in `NOTES_L2.md` and `REVIEW3_ANSWERS.md`, one folder up.
