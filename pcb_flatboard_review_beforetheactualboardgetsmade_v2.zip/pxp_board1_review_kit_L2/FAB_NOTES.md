# PxP board 1 — fabrication and assembly notes

Board: **PxP flip phone, board 1 ("flat test phone")**, schematic rev B1-0.7, layout L2, 12 November 2026.
Designed in KiCad 7.0 (files open in KiCad 8/9). Contact: the person who sent you these files.

## Bare board

| | |
|---|---|
| Size | 145.0 × 100.0 mm, corner radius 2 mm, routed outline |
| Layers | 4 copper |
| Thickness | 1.6 mm finished, FR-4 (Tg 150 °C or better) |
| Copper | 1 oz (35 µm) outer, 0.5 oz or 1 oz inner |
| Layer order | L1 `F.Cu` (top: signals + ground pour) · L2 `In1.Cu` (solid ground) · L3 `In2.Cu` (solid ground, no tracks) · L4 `B.Cu` (bottom: signals + ground pour, key pads) |
| **Stack-up** | **0.2 mm prepreg (7628) between L1–L2 and L3–L4**: NextPCB build `04161H03-7628`, JLCPCB `JLC04161H-7628`, or your equivalent. It is written in the board file (Board Setup → Physical Stackup). The RF line (0.35 mm on L1 over L2: 7 mm of track in three pieces from the modem pin to the antenna connector) is ≈ 50 Ω with this build only; no impedance test coupon is needed |
| Surface finish | **ENIG** (required: 0.5 mm pitch parts, and the key pads on the bottom are gold contact surfaces for metal domes) |
| Solder mask | both sides, any colour (green preferred); **vias tented on both sides** |
| Silkscreen | white, both sides (top: part labels; bottom: key names). If you print an order number, please put it on the bottom side away from the key pads |
| Smallest track / gap | 0.16 mm / 0.15 mm. These limits, 0.15 mm annular ring, 0.6 mm via pad, 0.3 mm plated hole and 0.3 mm hole-to-hole are the minimums in Board Setup. The project's rule file (`.kicad_dru`) adds: copper 0.25 mm from every hole, tracks 0.2 mm from the copper of plated component pads and 0.33 mm from their hole walls. KiCad's check runs against all of these: 0 errors |
| Vias | through vias only, (pad / drill) 0.60 / 0.30 mm × 1433, 0.70 / 0.35 mm × 35, 0.80 / 0.40 mm × 3. **No via-in-pad, no filled or capped vias**: no via is nearer than 0.15 mm to any soldered pad, nor to any stencil opening (see "Stencil" below). (The thermal-pad holes of U102, U105, U201 and U501 are 0.30 mm plated holes that belong to those footprints) |
| Smallest holes | plated 0.30 mm; **non-plated 0.50 mm at MK401 (microphone sound port: must stay open — no plating, no mask, no plug)**; non-plated 0.75 mm × 2 at J301 (nano-SIM locating pegs) |
| Fiducials | 3 (FID801–803), 1 mm copper in a 2 mm mask opening |
| Mounting holes | 4 × M2 with a copper ring (H801–H804) and 4 × M2 plain, non-plated (H805–H808, round the key pads) |
| Bottom side | **23 key pads** (SW501–SW523): a 1.6 mm centre pad inside a 3.0 / 4.8 mm ring, bare ENIG, **no solder paste, no part**. Each centre pad has one 0.3 mm plated hole inside it (its connection to the top side): leave it as drilled. Please keep the pads clean: metal domes are stuck on by hand later |

## Assembly

- **Top side only.** Nothing is soldered on the bottom.
- **The ESP32-S3-WROOM-1 module (U201) hangs 6 mm over the top edge** (its antenna, as Espressif recommends).
  The USB-C socket (J101) and the audio jack (J403) reach the board edge as well. Please put panel rails on the
  left and right edges, or leave a gap in the rail there.
- **BOM** `assembly/pxp_board1_BOM_assembly.csv`: fitted parts only, with manufacturer part numbers. Generic
  resistors and capacitors list an example part plus the spec any equivalent must meet (value, size,
  tolerance, dielectric, voltage).
- **Pick-and-place** `assembly/pxp_board1_CPL_top.csv`: fitted parts only (no test pads, fiducials, mounting
  holes, key pads or not-fitted parts). Rotations follow KiCad / IPC-7351 zero orientation: please check
  polarity and pin 1 against the assembly drawing `15_assembly_drawing_top.png`.
- **Not fitted (DNP)** — leave empty: C302, C314, C315, J103, J104, J105, J304, R110, R414, R419, R420, R422, R601, R703, R705.
  (KiCad 7 has no "do not populate" flag on footprints; these carry a `DNP` field instead. After opening the
  board in KiCad 8 / 9, "Update PCB from Schematic" sets the flag.)
- **Stencil: please use the paste layer as it is** (`gerbers/pxp_board1-F_Paste.gtp`). The modem's (U301) edge openings
  are 0.6 × 2.5 mm on 0.6 × 2.0 mm lands: they print 0.5 mm past the outer end of each land, as SIMCom's stencil
  drawing asks. No via and no track of another net lies under any stencil opening, so that overprint lands on
  solder mask only.
- Fine-pitch parts: QFN 0.4 mm (U403), WQFN 0.5 mm (U102, U501), TDFN 0.5 mm (U103), FPC 0.5 mm (J601, J602,
  J701), USB-C (J101), LCC+LGA-124 module (U301, SIMCom A7670G).
- Moisture-sensitive: U301 (SIMCom A7670G), U201 (ESP32-S3-WROOM-1) — please bake per their MSL labels.
- **C506 (Seiko CPH3225A backup capacitor): polarised, at most two reflow passes** (Seiko). The plus sign
  printed on its lid goes to pad 1, the end with the bar and the + on the silkscreen. Its two lands are drawn
  for the part's 1.0 × 1.0 mm end terminals (Seiko's drawing).
- **D502 (Lumileds LUXEON 2835 torch LED): the large pad is the cathode** (pad 1), as in Lumileds' data sheet.
- J601, J602 and J701 (Omron XF2M) take the ribbon with contacts on either face. Nothing is plugged in at
  assembly. The numbers printed at J601's two ends (45 and 1) are the display's pin numbers, not the connector's.

## Files in this kit

| Folder | What |
|---|---|
| `gerbers/` | Gerber X2 per layer, drill files (plated and non-plated separate, Excellon, mm), drill maps, job file |
| `assembly/` | BOM and pick-and-place |
| `kicad/pxp_board1/` | the KiCad project: board, schematic, custom rules (`.kicad_dru`), own symbols and footprints |
| `15_assembly_drawing_top.png` | the assembly drawing (the board file's F.Fab layer) |
