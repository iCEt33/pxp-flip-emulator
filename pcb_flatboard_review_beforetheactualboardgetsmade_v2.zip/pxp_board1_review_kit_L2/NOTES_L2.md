# PxP board 1 — what changed since review 3 (schematic B1-0.7, layout L2)

*12 November 2026, second issue of that day. Board 1 is the "flat test phone" of a DIY flip phone: every chip of the phone on one board
with test points, the keypad as dome pads on the back, screens and camera on short ribbons. This page lists
what changed after the third review and what a reviewer should know. Board coordinates are in mm from the
top-left corner, seen from the parts side. What is new against the first issue (B1-0.6) is gathered in the
last section, "12 November, second pass".*

## Schematic B1-0.7 (12 Nov) — one change on top of B1-0.6

| # | Change | Why |
|---|---|---|
| 1 | **OLED connector J602: Omron XF2M-3015-1A** (30 pins, 0.5 mm, contacts on both faces) instead of the top-contact Molex 54104-3031. Pad order unchanged: pad *n* = panel pin *n*; the "1" printed beside it marks pad 1. | Newhaven's mechanical drawing of the NHD-1.5-128128G: the driver chip and the gold contacts are on the front (screen-side) face of the ribbon tail, a stiffener is on the back, and with the screen seen from the front and the tail down, pin 1 is on the left. With the ribbon going straight into J602 (no fold) and the screen facing the key side, the contacts face the board, where a top-contact connector has none. Omron's sheet asks a ribbon 0.3 ± 0.05 mm thick with at least 2.5 mm of plated length; the tail's shoulders stop it 3.1 mm into the 3.45 mm slot. Put in mirrored by mistake, the 13 V lands on a pin the panel does not use. Picture `17_oled_ribbon_which_way_round.png`. |

## Schematic B1-0.6 (12 Nov) — two changes on top of B1-0.5

| # | Change | Why |
|---|---|---|
| 1 | **TFT connector J601: pad order reversed.** Pad *n* now carries the display's pin *46 − n* (pad 1 = display pin 45 … pad 45 = display pin 1). The numbers printed at the connector's two ends, 45 and 1, are the display's pin numbers. | The TFT has to be seen from the key side. Displaytech's drawing of the DT024CTFT (section 4) shows the contacts on the back face of the ribbon tail and, seen from behind with the tail down, pin 1 on the left. With the old order the display would have lain face-up on the parts side. With the ribbon going straight into J601 (no fold) and the display hanging past the board edge, the reversed order turns the screen to the key side, upright above the keys. Picture `16_tft_ribbon_which_way_round.png` shows it. J601 takes contacts on either face, so the contact side needs no change. |
| 2 | U401, U402, U405 (TS5A22362): footprint link `pxp:VSSOP-10_3x3mm_P0.5mm`, a copy of KiCad 7's footprint in the project library. | Review 3: newer KiCad versions do not find that name in their `Package_SO` library. |

## Schematic B1-0.5 (11 Nov) — what changed after review 3

| # | Change | Why |
|---|---|---|
| 1 | **Gauge: BQ27220 → MAX17048G+T10** (U103, 8-pin TDFN 2 × 2 mm, I²C 0x36). The 10 mΩ sense resistor R115, C116, R116 and the `VBAT` net are gone: `BATT_RAW` → 0 Ω link R114 (ammeter header J103) → `BAT`. 100 nF (C115) at VDD; ALRT → `GAUGE_INT` (10k pull-up). | The BQ27220's centre ball needed a filled via (special process). The MAX17048 has no balls and no sense resistor; used on the LG Nexus 5, Adafruit ESP32-S3 Feather, SparkFun Thing Plus ESP32-S3. It reports % from the cell voltage, not mA. |
| 2 | **Camera SDA / SCL on their own two pins**: GPIO16 (module pin 9) = `CAM_SDA`, GPIO48 (pin 25) = `CAM_SCL`, 2.2k pull-ups R709 / R710 to `CAM_2V8`. Option resistors R314 / R315 removed. | With the camera rail off (0 V, actively discharged) the sensor's pin diodes could clamp the shared I²C bus and lock out the expander that switches the camera on. Firmware: when the camera is off, set both pins to inputs without pull-ups. |
| 3 | **Ribbon connectors with contacts on both faces**: J601 (TFT) Omron XF2M-4515-1A, J701 (camera) Omron XF2M-2415-1A. J602 (OLED) stayed Molex 54104-3031 at that point (the type Newhaven names). | The contact face of the ribbons was not confirmed at that point; a two-way connector works with either. (The TFT's pin order was settled in B1-0.6 and the OLED's connector in B1-0.7, both above; the camera is still open, see the end of this page.) |
| 4 | **All 23 keys are bare gold pads for 4 mm metal domes** (SW501–SW523, `pxp:KeyDome_4mm`, no part, not in the BOM), on the bottom side at the phone's key positions; the two volume keys too (beside the keypad). 4 deck holes H805–H808 (M2, un-plated). | A printed keypad deck is to be laid over board 1. Domes go on by hand under tape, as in the phone. |
| 5 | **Clock backup**: PCF85063A VDD on its own node `RTC_VDD`, fed from +3V3 through D509 (1N4148WS); R515 330 Ω to C506, a Seiko CPH3225A 11 mF / 3.3 V capacitor; test point TP506. | The clock keeps time for about a day while the battery is swapped (NXP data sheet figure 31). Firmware must switch CLKOUT off. |
| 6 | Modem rail **4.14 V** (R125 604k → 590k; was 4.22 V). | Review 3: 4.22 V was too close to the A7670's 4.2 V limit. |
| 7 | Headphones: R423 fitted, R422 not fitted, so left and right both come from `AUD_P` (same phase). | Review 3: with R422 the two ear-pieces were in anti-phase. |
| 8 | Fewer part types: USB series 27R → 22R, charger PMID 6.8u → 10u, camera clock 33R → 22R, buck feed-forward and SIM 22p in 0402, modem 100n in 0603, MBR0520 → MBR0540, NETLIGHT LED green. | Each BOM line costs a set-up fee at the assembler. |
| 9 | Footprints: thermal vias of U102 / U501 / U105 / U201 with 0.3 mm holes; MK401's sound hole 0.5 mm; pin map note and tables updated; MPN / manufacturer / spec written into every symbol. | Review 3 / maker limits; so the board file alone carries the part numbers. |

Still to confirm: the camera's ribbon (end of this page). The **CPH3225A land pattern** is settled: it is drawn
from Seiko's own drawing now (two 1.0 × 1.0 mm end terminals; lands 1.3 × 1.2 mm), and the LUXEON 2835's pads
were checked against Lumileds' sheet (large pad = cathode = pad 1; no change).

## Layout L2 — what changed after review 3

### The board

| | L1 | L2 |
|---|---|---|
| Size | 160 × 110 mm | **145 × 100 mm** (17,600 → 14,500 mm²) |
| Layers | signal / ground / +3.3 V / signal | signal / ground / **ground** / signal; 3.3 V and VSYS are tracks now |
| Stack-up | none in the file | maker's 1.6 mm build with **0.2 mm (7628) prepreg** outside: NextPCB `04161H03-7628`, JLCPCB `JLC04161H-7628`; written into the board file |
| Keys | 21 switches on top | **23 dome pads on the bottom** at the phone's key positions (incl. VOL+ / VOL−), 4 holes for a printed deck |
| Vias in or touching soldered pads | 169 | **0 of 1,471 (nearest via copper to a pad ≥ 0.15 mm)** (rule: no via copper within 0.15 mm of any pad or stencil opening) |
| Mounting | 4 corner holes | 4 holes with copper rings (one moved away from the antenna) + 4 plain deck holes |

**Why 145 and not 130 mm wide.** The modem, the power block and the ESP32 module sit side by side along the top
edge; 140 mm already did not fit. The ESP32's antenna end hangs 6 mm past the top edge (Espressif's
recommended mounting), which is what made 100 mm of height enough.

**Holes.** H801 (3.6, 3.6), H803 (3.6, 96.4), H804 (141.4, 96.4), and **H802 at (101.5, 3.6)** — not in the
top-right corner, because that corner is the antenna (Espressif: 15 mm clear of metal; H802 is 18 mm away).
Deck holes H805–H808 at (77, 35), (123, 35), (77, 97), (123, 97): plain, no copper. Tallest part on the top
side ≈ 5.5 mm (battery connector, audio jack), so printed legs of 8–10 mm let the board stand keys-up.

**Keypad.** Seen from the bottom with the board flipped top-over-bottom, the keys are where they are on the
phone (frame origin at board (100, 66)). Each key is a 1.6 mm centre pad inside a 3.0 / 4.8 mm ring, bare
gold (ENIG), no solder paste; the centre's via sits 0.45 mm off-centre under the dome's rim side. The key
names are printed beside the pads. VOL+ / VOL− were first meant to stay push-buttons; they became dome
pads too, at (70.5, 80.5) and (70.5, 71.5), so every key is on the key face and nothing is soldered on the
bottom. The six key-backlight LEDs stay ordinary top-side LEDs (they only prove the circuit here).

### Placement changes

- Decoupling capacitors and the boost loops, measured on the finished board,
  pin to capacitor pad in mm (L1 in brackets): ESP32 3.3 V 1.8 (5.5) · buck input 1.7 (3.8) · charger PMID 1.5
  (3.2), VBUS 1.5 (5.4), SYS 1.5 (4.5) · modem 1.8 V output 2.9 (14.5) · gauge 2.0 (4.1) · keypad chip 3.1
  (4.2) · clock chip 1.6 · backlight boost input 1.2 (10.4) · OLED boost input 1.7 (7.9). Backlight boost:
  inductor 2.2, diode 1.5 from the switch pin (6.4 / 4.6). OLED boost: 2.4 / 2.5 (4.9 / 4.7). Crystal: 2.7 / 2.0
  from the clock chip's two pins (5.7), both tracks on top with no via.
- A **clear strip** (no small parts) beside the camera connector's pads and north of it up the right edge, so
  each of its 21 used pins has room for its own track and via; the camera's two regulators and its oscillator
  sit 3 mm further from the connector.
- Microphone pairs short and on top: MICP_SW / MICN_SW 12 / 16 mm (L1: 68 mm with 3–6 vias); every microphone
  and crystal net is on the top layer with **no via** (HMIC_OUT / HMIC_VDD, the two not-fitted option links,
  excepted).

### Routing rules new in L2

1. **No via copper within 0.15 mm of any soldered pad** (the pad map is taken one grid cell wider than drawn,
   so a pad off the 0.05 mm grid cannot come nearer either). No via-in-pad anywhere, so no filled or capped
   vias. The plated holes in the exposed pads of U102, U105, U201 and U501 belong to those footprints.
   **(12 Nov, second pass) Stencil openings count as pads too:** no via within 0.15 mm of one, and no track of
   another net within 0.10 mm of one that reaches past its land (the modem's edge lands).
2. **Planned fan-out** before anything else is routed, because a 0.6 mm via does not fit between 0.5 mm-pitch
   pins: every used pin of the three ribbon connectors (four via columns: out-near, out-far, in-near, in-far,
   so each column has 2 mm pitch), of the keypad chip and the charger (tracks spread to a row of vias at
   0.8 mm pitch), the expander (two staggered columns) and the codec's four I²S pins gets a short 0.16 mm track
   to a via of its own. Vias the finished routes did not need were removed again.
3. **Microphone and crystal nets first, top layer only**, then the supply trunks, then signals. Microphone nets
   keep 5 mm from the five switching inductors.
4. **3.3 V and VSYS as tracks:** 1.0 mm trunks (charger → buck; buck → ESP32's capacitor row → pin 2), 0.5 mm
   branches; near the fanned-out chips a branch costs extra, so it does not fence their pins in.
5. **SPI clock and data as a chain** (source resistor → microSD → TFT → OLED), not a star.
6. **Long nets before short ones** (a short net blocked by a long one is easy to repair locally; the other way
   round is not). Ground-only top copper under the modem and the ESP32 (since the second pass: up to 0.2 mm
   from the inner ends of their pad rows), ground-only bottom copper under the crystal.
7. **(12 Nov) More room round holes:** tracks keep 0.2 mm from the copper of plated component pads (header pins,
   the USB-C shell, the mounting-hole rings, the via-like centre contacts of the key pads) and 0.33 mm from
   their hole walls, and 0.26 mm from un-plated holes. These are rules in the project's `.kicad_dru` now, so
   KiCad checks them every time.

### Result

**Every connection is made. KiCad's own rule check (zones refilled): 0 violations, 0 unconnected. Every pad
carries the net the B1-0.7 schematic gives it (435 parts, 1,272 pins).** The check runs against maker-level
minimums (below), not the loose ones review 3 found.

| | L2 | L1 |
|---|---|---|
| Vias | 1,471 (1,433 at 0.6 / 0.3 mm, 35 at 0.7 / 0.35, 3 at 0.8 / 0.4), 625 of them ground | 1,438 (865 ground), one of them 0.40 / 0.20 mm |
| Smallest track / gap | 0.16 / 0.15 mm | 0.16 / 0.15 mm |
| Smallest plated hole | 0.30 mm | 0.20 mm |
| Track | 4.49 m top, 4.29 m bottom, **none on layer 3** | 4.1 m top, 3.5 m bottom |
| VSYS | 37 mm at 1.0 mm, 251 mm at 0.5 mm (plus two 1 mm necks at pins) | 236 of 237 mm at 0.3 mm |
| I²C data / clock | 230 mm, 29 vias / 181 mm, 15 vias (camera now on its own bus) | 309 mm, 30 vias / 254 mm, 29 vias |
| SPI clock / data out | 156 mm, 9 vias / 143 mm, 6 vias, each one line: resistor → microSD → TFT → OLED | 129 mm, 10 vias, a star with three branches |

**Rules the check runs against (12 Nov).** Board Setup minimums: clearance 0.15 mm, track 0.15 mm, via ring
0.15 mm, via pad 0.6 mm, plated hole 0.3 mm, hole to hole 0.3 mm. Rule file: copper 0.25 mm from every hole;
tracks 0.26 mm from un-plated holes, 0.2 mm from plated component pads and 0.33 mm from their holes; 0.5 mm
between the antenna line and the pours; two exceptions that apply only between pads of the same part (the
USB-C socket's peg holes, the microphone's sound port). Not met, on purpose: the 0.5 mm between holes of
different nets that some community rule files carry (31 pairs of holes are 0.46 to 0.49 mm apart; the makers'
own pages ask 0.2 to 0.45 mm), and JLCPCB's printed silkscreen figure of 1.0 mm text with 0.15 mm lines (most
labels here are 0.8 mm with 0.12 mm lines, to fit beside the parts).

**How it was routed.** One first pass (about 4 minutes) leaves 30–50 connections open;
a repair pass then closes them: take up only the copper within a few mm of a blocked pin, route the blocked
net first, keep the result only if fewer connections are open (most cases); for a connection blocked
somewhere along its way, cut only what lies on its best path and reconnect the others; and a two-level version
of that. KiCad's own connection check is the judge after every stage. Four
placements were tried (camera strip, room in front of the ESP32, the expander moved); the board is the second
one, which closed all but two connections.

**Layer 3 carries no track.** In the first issue two connections crossed on it (CAM_D7 for 11.5 mm, EXP_MDM_DTR
for 23 mm) because nothing else closed them. Both run on the outer layers now: CAM_D7 is 42 mm with
4 vias, EXP_MDM_DTR (the modem's sleep line, a steady level) 85 mm with 12 vias. Layers 2 and 3 are
ground without a break.

### What a reviewer should still know (honest limits)

- **C501 (keypad chip's 100 nF) is ≈ 3 mm from pin 21**, not under 2 mm: all 24 pins of that chip are in use and
  at 1.9 mm five of them could not get out.
- **USB D+ changes layer four times, D− twice** (22.5 mm / 26.4 mm). The two extra vias came with clearing the
  tracks from under the ESP32's edge. The ESP32's own USB is full speed (12 Mbit/s).
- **Long control lines with many vias:** EXP_MDM_DTR (85 mm, 12 vias), the keypad interrupt line
  (124 mm, 15). Both are steady levels.
- **Labels:** 197 designators are printed (L1: 29): chips, connectors, coils and not-fitted options first,
  wherever a free spot beside the part exists (some sit over tented vias), and 43 of the 73 test points print
  their net name. Not printed, for lack of room: U104, U105, U303, X701, J501, J104, L102, L103, FB407, about
  115 small resistors, capacitors and diodes, and 30 test points — all of these are on the assembly drawing
  (the board file's F.Fab layer). The ESP32 module and the USB-C socket carry no label either. **Marks:** − and
  + at the two ends of the battery connector (− left, + right, as its pins are), pin numbers at the ribbon
  connectors (J601: 45 and 1, which are the display's pin numbers; J602: 1; J701: 1 and 24), and RESET, BOOT and QON at their buttons.
- **Key pads:** each centre pad has its 0.3 mm plated hole inside the pad (that is how the centre reaches the
  top side). These pads are bare contact surfaces for domes, not soldered, so the "no via in a pad" rule is
  about soldered pads only.
- **C506 (Seiko CPH3225A backup capacitor):** polarised, at most two reflow passes. The plus sign on its lid
  goes to pad 1 (marked on the silkscreen).
- **Earpiece and microphone pairs** were laid by the router, not drawn by hand side by side with ground vias.
  The microphone and speaker pairs are on the top layer without a via; the earpiece pair changes layer twice.
- **Ribbons.** *TFT (J601)* and *OLED (J602)*: settled from the makers' drawings, not from parts in hand (B1-0.6
  and B1-0.7 at the top). Not yet checked: that the TFT's tail is plated far enough for the Omron's 3.45 mm
  slot (Omron asks 2.5 mm or more). On the bench the two screens hang side by side past the bottom edge and
  their glass edges overlap by about 1 mm (picture 17): one rests on the other. The headphone jack is 17 mm to
  the left of the OLED's connector, so a plug in it lies over the OLED's corner: swing the OLED aside or
  unplug it. Nothing to change for a test board. *Camera (J701):* two-way
  connector, pin order not yet checked against a module (it varies between sellers). With an OV2640 module,
  remove R701 first (it wants 1.2 V, not the 1.5 V rail).
- **Standby current** is on paper only (`SLEEP_BUDGET.md`), and SIMCom gives no sleep figure for the modem.
- The I²S lines change layer by the codec and by the ESP32 (L1 kept them on top). The codec's I²C data and
  address pins leave by two hand-drawn tracks between the microphone capacitors.

## 12 November, first pass: what changed after the first L2 files

1. **J601's pad order reversed (B1-0.6)** and the copper round it made again. Only an area of 60 × 28 mm
   round the connector was opened; everything else stayed as it was. 20 nets changed there. The SPI clock and
   data were routed afresh as a chain with the TFT's new pads in it. The supply branch to the backlight boost
   now runs along the bottom edge.
2. **Maker-level rules** in Board Setup and the rule file (above). 20 places where a track passed a plated
   component pad at 0.15 to 0.19 mm, or an un-plated hole at 0.25 mm, were routed again a little further away.
   The two footprint exceptions in the rule file had also applied to the ground pours near every hole (0.20 mm
   instead of 0.25 mm); they are pad-to-pad only now, and the pours keep 0.25 mm.
3. **34 duplicate track pieces removed** (125 mm in all): pieces lying wholly inside another track of the same
   net, left behind by repair passes. No connection changed.
4. **Microphone MK401:** the four stencil openings of its broken solder ring had 0.1 mm anchor pads, which a
   pad-size check reads as 0.1 mm pads. Anchors are 0.2 mm now, inside the same openings (opening area
   unchanged, 0.164 mm² each).
5. Footprint link of U401 / U402 / U405 (B1-0.6, item 2). The date printed on the board is 2026-11-12.

## 12 November, second pass: what is new in this issue

Asked for by review 3 and left open in the first issue:

1. **J602 is a two-way connector** (B1-0.7, top of this page). It sits on the old pad centres; its two fitting
   pads got new ground links. Nothing else moved.
2. **Layer 3 is free of tracks.** CAM_D7 and EXP_MDM_DTR were taken off it and laid on the outer layers.
3. **Nothing under the ESP32's edge.** I2S_DIN, MDM_TXD_3V3 and SPI_MISO ran along the inner ends of its pad
   rows for 6 to 10 mm. They leave their pads outward now; 20 nets were laid again in a 37 × 34 mm window.
4. **Earpiece line EAR_N: two layer changes instead of four** (one via of a neighbouring line moved 2 mm).
5. **C506's lands from Seiko's drawing**, with the track that ran under the part moved to the middle between
   its terminals and one via moved out from under it. **D502's pads confirmed** against Lumileds' sheet.
6. **Sleep-current budget** written (`SLEEP_BUDGET.md`). **OLED 13 V switch: decided against for board 1**
   (`REVIEW3_ANSWERS.md`).

Found on the way, not in the review:

7. **Vias under the modem's solder paste.** SIMCom's stencil drawing makes each edge opening 0.6 × 2.5 mm on a
   0.6 × 2.0 mm land: paste is printed 0.5 mm past the land onto the solder mask. The via rule looked at
   copper pads only, so 22 vias stood under or within 0.15 mm of that paste, 11 with the hole under it; and 5
   track pieces of another net lay under it. Now stencil openings count as pads (routing rule 1). The 17
   connections concerned were laid again with their vias 0.5 mm further out; 7 ground lands got a new stub
   and via. In the same pass the two tracks that ran under the modem's corners (MDM_NETLIGHT 5 mm, SIM_RST_M
   6 mm, just inside the pad rows) went out: **no top-layer signal track is under either module**, measured
   inside the inner ends of the pad rows.
8. **Copper that does nothing.** A repair that lays a connection a second way had left the first way in place.
   KiCad reports neither a loop nor a dead end whose tip is a knot of short pieces (no end "dangles"). The
   first issue's files had 8 dead-end branches of 1.5 mm or more (96 mm in all: AUD_N 39 mm, SPI_MISO 24,
   TFT_TE 10, AMP_VOP 7, CODEC_AUD_P 7, LCD_RST 4, KEY_RST 3, CAM_D1 2) and 5 loops in signal nets (AUD_P
   38 mm, the modem's power-key line three times, the keypad interrupt line); today's own repairs had added
   more. All are gone. Each removal was checked: the net's pads must still hang together, and KiCad's check
   must stay at 0 unconnected. The one ring left is in the 3.3 V supply (a second feed, kept).
9. **Checks that now run on every issue**, besides KiCad's own: board against schematic; vias against copper
   pads; vias and other nets' tracks against stencil openings; top-layer tracks under the two modules and
   tracks on the inner layers; loops and dead ends; joints narrower than the smallest track (none). All pass
   on the files in this kit.

Numbers against the first issue: vias 1,466 → 1,471 (ground 625, 607 before); track 4.49 m top and
4.29 m bottom (4.52 / 4.34), none on layer 3 (35 mm); I²C data 230 mm with 29 vias (222 / 29); keypad
interrupt line 124 mm (160); headphone lines AUD_P / AUD_N 57 / 37 mm (95 / 77); hole pairs of different
nets under 0.5 mm: 31 (38).
