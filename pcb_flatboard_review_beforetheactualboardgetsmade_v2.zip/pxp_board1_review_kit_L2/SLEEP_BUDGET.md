# PxP board 1 — sleep-current budget

*12 November 2026, schematic B1-0.7. Asked for in review 3 ("write a sleep-current budget, one line per part,
then measure"). This is paper work: every figure is a data-sheet value for the part's lowest-power state, added
up. Nothing here changes the board. It says what to expect on the ammeter, what firmware must do to get there,
and which parts decide the result.*

## Short version

| State | What is on | Expected at the battery (3.8 V) | BL-5C (1020 mAh) lasts |
|---|---|---|---|
| **Asleep, modem off** | ESP32 in deep sleep, clock, keypad chip, charger, gauge | **about 0.3 mA** as built; about 0.18 mA with the hinge microphone unpowered | about 5 months / 8 months |
| **Standby, modem registered** | the above + modem asleep on the network | modem's sleep current × 1.3 (**SIMCom gives no figure: "TBD"**) + about 0.45 mA; on board 1 about 1.4 mA more for the STATUS light | examples only: a 2 mA modem → about 2 weeks; 4 mA → about 1 week (STATUS light off) |

Not in the sums, because their data sheets give no figure: the **TFT in sleep** and the **microSD card when
idle**. Both sit on the 3.3 V rail with no switch. Measure with and without each.

Target for the bench: **asleep with the modem off ≤ 0.35 mA** with card and screens unplugged. Anything well
above that means a part was not put to sleep (list below).

## Asleep, modem off — line by line

| Part | Fed from | Data sheet, lowest state | Counted | Note |
|---|---|---|---|---|
| U102 charger BQ25896 | battery | 32 µA typ, 60 max (battery only, BATFET on, ADC off) | 32 µA | 12 µA in shipping mode (BATFET off: board dead until QON is pressed) |
| U103 gauge MAX17048 | battery | 23 µA active, 4 µA hibernate | 23 µA | goes to hibernate by itself when the cell is idle |
| U105 modem boost SGM6609 | battery | off: 1 µA max, output cut from input | 1 µA | R128 (100 k to PG) carries nothing while the boost is off |
| U104 3.3 V buck SY8089A | VSYS | 55 µA with no load | 55 µA | always on |
| R119 + R120, buck feedback | 3.3 V | 3.33 V / 122 k | 27 µA | |
| U601 backlight boost TPS61160 | VSYS | off: 1 µA max | 1 µA | |
| U602 OLED boost SX1308 | VSYS | off: about 1 µA | 1 µA | |
| R606 + R607 on OLED_VCC | VSYS through L602, D604 | (VSYS − 0.3 V) / 650 k | 5 µA | the 13 V rail rests at battery voltage when "off" |
| U201 ESP32-S3 module | 3.3 V | deep sleep 8 µA (Espressif measured 8.14 µA on this module) | 8 µA | light sleep is 240 µA |
| U501 keypad chip TCA8418 | 3.3 V | idle 3 µA | 3 µA | **+33 µA for every input held low against its internal 100 k pull-up** |
| U502 expander PCA9535 | 3.3 V | standby below 1 µA | 1 µA | **+33 µA for every output held high into a 100 k pull-down** |
| U503 clock PCF85063A | 3.3 V through D509 | 0.22 µA | 0.2 µA | with CLKOUT switched off |
| U504 lid sensor DRV5032FA | 3.3 V | 1.6 µA typ, 3.5 max | 1.6 µA | push-pull output |
| U401, U402, U405 switches TS5A22362 | 3.3 V | 0.1 µA typ, 1.2 max each | 0.3 µA | |
| U403 codec ES8311 | 3.3 V | power-down 0 µA (data-sheet table) | 0 µA | only after firmware powers it down |
| U404 speaker amplifier NS4150B | 3.3 V | shutdown below 1 µA | 1 µA | |
| U302 level shifter TXB0104 | 3.3 V (modem side at 0 V) | 5 µA max | 5 µA | outputs float while the modem is off |
| U701, U702 camera regulators | 3.3 V | off: about 1 µA each | 2 µA | |
| **MK402 hinge microphone** | 3.3 V through R417 | **120 µA typ, 160 max** | **120 µA** | always powered on board 1 |
| OLED panel logic (VCI) | 3.3 V | sleep 4 µA typ, 20 max (Newhaven) | 4 µA | |
| R425 headphone detect | 3.3 V | 3.3 V / 580 k with no plug in | 6 µA | |
| TFT panel logic | 3.3 V | **not in the ILI9341 data sheet** | ? | after reset the chip is in "sleep in" with the display off |
| microSD card | 3.3 V | **card-dependent** | ? | one set of tests on the web: tens of µA, about 70 µA for older cards |

3.3 V rail: about 152 µA (32 µA without the microphone). The buck turns that into about the same current at
the battery (3.33 V / 3.8 V at roughly 90 % efficiency). Battery side: 32 + 23 + 1 + 55 + 27 + 1 + 1 + 5 ≈
145 µA. **Total about 0.30 mA; 0.18 mA with R417 lifted.**

## Standby, modem registered — what is added

| Part | Adds | Note |
|---|---|---|
| U301 modem A7670G asleep | **? mA** | SIMCom's hardware guides (V1.00 and the A7672X/A7670X guide) list sleep and idle current as "TBD". Measure at J105. It reaches the battery multiplied by about 1.3 (4.14 V from 3.8 V at about 85 %) |
| U105 boost running | 50 µA typ, 70 max | |
| R125 + R126, boost feedback | 6 µA | |
| R128 on PG | 38 µA | PG is low while the output is good |
| R123 on BOOST_EN | 33 µA from 3.3 V | the expander holds the enable high into 100 k |
| U302 level shifter, both sides on | up to 10 µA | |
| **D302 STATUS light** (R307, Q303) | **0.9 mA + 0.23 mA** on the modem rail, about 1.4 mA at the battery | lit whenever the modem is on: (4.14 − 2.0) V / 2.2 k, and (1.8 − 0.7) V / 4.7 k into the transistor |
| D303 NETLIGHT | 0 while asleep | SIMCom: off in sleep; blinks when awake |
| ESP32 | 8 µA in deep sleep, 240 µA in light sleep | deep sleep wakes by restarting: firmware's choice |

Without the modem itself: about 0.45 mA at the battery, plus about 1.4 mA for the STATUS light on board 1.

## What firmware has to do (each one is a line in the table above)

1. **Keypad chip pull-ups off on the inputs that can sit low**: LID_DET (the sensor drives it; lid closed = low)
   and SD_DET (card in = low). Register GPIO_PULL. Otherwise 33 µA each. HP_DET has its own divider.
2. **Screens held in reset while asleep** (LCD_RST low). Released, the expander drives 33 µA into R612.
3. **Codec powered down** over I²C before sleeping; **amplifier off** (AMP_EN low: it has a 10 k pull-down,
   330 µA if left high).
4. **Clock chip CLKOUT off** (it is on by default).
5. **Modem off = boost off** (MDM_PWR_EN low), not only the modem's power key.
6. ESP32 pins: nothing driven against a pull-up or pull-down; SD, TFT and OLED chip selects left to their
   10 k pull-ups.
7. Standby: modem to sleep (AT+CSCLK=1, DTR high: SIMCom low-power note), NETLIGHT off if wanted.

## How to measure (the board has the places for it)

- **J103 / R114** total battery current, **J104 / R121** the 3.3 V rail, **J105 / R127** the modem rail. Each
  is a 0 Ω link with two header holes beside it.
- A multimeter on its µA range cannot carry the start-up current (hundreds of mA): the board would reset.
  So: take the 0 Ω off, solder a 2-pin header into J103 and put a jumper on it. Clip the meter across the two
  pins **with the jumper still on**, let the board go to sleep, then pull the jumper: now the meter carries
  the sleep current. Jumper back on before waking the board.
- Order: bare board first (no card, no screens, no camera), then add one thing at a time and write down the
  step: microSD card, TFT, OLED.
- **For the standby figure take R307 off** (STATUS light), or the reading is about 1.4 mA too high.
- To see what the hinge microphone costs: lift R417 (120 µA expected).

## For the phone boards (not board 1)

- **Hinge microphone on a switched supply** (largest single line when asleep).
- **microSD on a switched supply** if the card's idle current turns out high.
- STATUS / NETLIGHT lights not fitted.
- R128 could be 1 MΩ (saves about 35 µA in standby); R612 / R123 could be 1 MΩ as well.
- The 13 V switch for the OLED: not needed for current (5 µA).

## Sources

Read on 12 November 2026: Espressif ESP32-S3 data sheet (table of low-power modes) and Espressif's
module current measurements; TI BQ25896, TCA8418, TS5A22362, DRV5032 data sheets; SG Micro SGM6609 Rev. A;
Silergy SY8089 / SY8089A; Everest ES8311 Rev. 7.0; Newhaven NHD-1.5-128128G; SIMCom A7670 Series Hardware
Design V1.00, A7672X/A7670X Hardware Design, A76XX Low Power Mode note; ILI9341 data sheet. Taken from the
parts' headline figures without re-reading the tables today: MAX17048, PCA9535, PCF85063A, NS4150B, TXB0104,
TPS61160, SX1308, TLV743P, Knowles SPU0410HR5H (figure from review 3).
