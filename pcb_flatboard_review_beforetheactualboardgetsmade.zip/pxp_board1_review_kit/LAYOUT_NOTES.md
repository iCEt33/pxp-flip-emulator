# Board 1 PCB layout notes

*27–29 October 2026, schematic rev B1-0.4 / layout L1. Board 1 is the roomy
"flat test phone": every chip of the phone on one board with test points,
screens and camera on short ribbons. This page says how the layout was made
and why, so a reviewer can check it.

**Status:** **Layout L1 finished 29 Oct 2026: every connection made; KiCad's own rule check (DRC) reports 0 violations and 0 unconnected pads; every pad carries the net the B1-0.4 schematic gives it (431 parts, 1272 pins checked).**

**Silkscreen tidied later on 29 Oct (no copper change, DRC and pin check re-run: still 0 / 0 / OK):** 

---

## 1. The board

| | |
|---|---|
| Size | **160 × 110 mm**, 2 mm corner radius, 4 × M2 mounting holes (one per corner, H802 top middle instead of top right: the ESP32 antenna sits in that corner) |
| Layers | **4 copper, 1.6 mm** (user, 27 Oct): stiff for bench work |
| Stack-up | **L1 F.Cu** signals + GND pour · **L2 In1** solid GND · **L3 In2** solid +3.3 V · **L4 B.Cu** signals + GND pour. Standard 1.6 mm 4-layer build (~0.2 mm prepreg L1–L2 and L3–L4, ~1.1 mm core) |
| Parts | 431 footprints: 334 parts placed by the factory, 17 not fitted on board 1 (DNP), 80 test pads, fiducials and mounting holes; 1672 pads |
| Finish | **ENIG** (gold): flat pads for the 0.5 mm-pitch chips and the 0.5 mm ball-grid gauge; also what the keypad domes need on board 2 |
| Assembly | Top side only. Bottom side has no parts |

**Why 4 layers with two solid planes:** every signal on L1 sits right above an
unbroken ground plane (L2), and every signal on L4 above the +3.3 V plane (L3).
That keeps return paths short (less noise into the call audio and the antenna),
gives every ground pin a 1-via path to ground, and feeds 3.3 V to the chips
without wide traces. Only signals use L1 and L4.

---

## 2. Placement — what sits where and why

Board-local coordinates in mm (x right, y down, 0,0 = top-left corner).

| Block | Where | Why there |
|---|---|---|
| **Modem** A7670G (U301) | top left (31, 30) | Its antenna pad (60) faces the top edge: the RF path to the u.FL (J303, top edge) is a straight 13 mm line. VBAT pads (55–57) face the power block on its right |
| **Modem supply** SGM6609 boost (U105), 2 × 330 µF, SIMCom's 33p/10p/100n/1µ, TVS | between the modem and the charger | SIMCom V1.03 §3.1.1: VBAT copper ≥ 3 mm, caps "near Vbat". The 3 mm copper runs from the boost output past the caps into the VBAT pads |
| **Battery path** connector J102 → 10 mΩ sense (R115) → gauge (U103) → charger (U102) | top middle | Short, wide battery copper; the gauge sits on the sense resistor (Kelvin traces) |
| **USB-C** (J101), ESD (U101), 3.3 V buck (U104) | top middle-right | USB at the top edge; VBUS goes straight down to the charger |
| **ESP32-S3 module** (U201) | top right, antenna at the top edge | Espressif: antenna at the board edge, nothing (no copper on any layer) beside or under it — a 40 × 6.6 mm keep-out |
| **Camera** FPC (J701), its 2.8 V / 1.5 V LDOs and 24 MHz clock | right edge, below the ESP32 | Eight of the 11 camera lines leave the module's right side |
| **Audio** codec ES8311 (U403), switches (U401/U402/U405), amp (U404) | middle | Between the modem's audio pads, the ESP32's I²S pins and the jack / speaker connectors at the bottom |
| **Keypad** 21 keys + volume (SW501–523), keypad chip (U501) | bottom left | Grid like the phone's keypad; the keypad chip in the middle of its 25 lines |
| **Expander** (U502), clock (U503), lid sensor (U504) | centre / bottom | Expander outputs go everywhere: centre is shortest |
| **Screens** FPCs (J601 TFT, J602 OLED), microSD (J603), backlight and OLED boosts | bottom / right edge | Ribbons leave the bottom edge like the hinge flex will; the card enters from the right edge |
| Jack, speaker, earpiece, vibra, torch | bottom edge | Plugs and wires come in from the edge |

Small parts (resistors, capacitors, test points) were placed by script next to
the pins they connect to, with two rules: **nothing within 0.8 mm of a
fine-pitch chip, and nothing in a 2 mm band in front of any fine-pitch pin**
(QFN, BGA, TSSOP, FPC, USB-C), so every pin can get its trace out.

---

## 3. Copper rules

**Net classes** (track / clearance / via; widths from IPC-2221, outer layer,
1 oz, ~10 °C rise):

| Class | Track | Clearance | Via | Nets |
|---|---|---|---|---|
| Default | 0.20 | 0.15 | 0.6 / 0.3 | all signals |
| Supply | 0.30 | 0.15 | 0.6 / 0.3 | small rails on fine-pitch pins: CAM_2V8, CAM_1V5, AVDD_CODEC, OLED_VCC, backlight anode |
| Power | 0.50 | 0.20 | 0.7 / 0.35 | VSYS, VBUS, +3V3 branches, buck, speaker, vibra, torch |
| Switch | 0.80 | 0.20 | 0.7 / 0.35 | charger and boost switch nodes (kept short) |
| Battery | 1.50 | 0.15 | 0.8 / 0.4 | BATT_RAW, VBAT, BAT |
| Modem_VBAT | **3.00** | 0.20 | 0.8 / 0.4 | VDD4V2 (SIMCom ≥ 3 mm) |
| RF | 0.35 | 0.20 | — | modem antenna path |

Near a small pad a wide track may **neck down** for its last 1.2 mm (0.8 × the
pad's width, at least 0.15 mm), like a hand-drawn board.

**Custom rules** (`.kicad_dru`): hole-to-copper 0.25 mm everywhere except the
USB-C plastic pegs (GCT's land pattern: 0.19 mm, rule 0.15) and the bottom-port
mic's sound hole (0.20); RF trace to ground pour 0.5 mm.

---

## 4. Power copper (drawn by hand, not by the router)

- **VDD4V2** (modem supply): a **3 mm copper shape** from the boost output
  (via the 0 Ω board-1 current-measuring link R127) along both 330 µF caps and
  over the VBAT pads 55–57 (SIMCom V1.03 §3.1.1).
- **Boost** SGM6609: switch node SW → inductor 2.2 µH as one short shape;
  output shape to the output cap; FB / ISET leave between them; AGND–PGND
  joined under the chip (SG Micro layout guide).
- **Battery**: connector → R114 (0 Ω link) → VBAT → 10 mΩ sense R115 → BAT →
  charger BAT pins and boost input, all 1.5 mm or wider shapes.
- **Gauge** BQ27220: SRP / SRN are **Kelvin traces** to the sense resistor's
  pads (TI). The centre ball (B2, ground) uses a **filled and capped via in the
  pad** (0.40 / 0.20 mm) — the only way out of a 3 × 3 ball grid.
- **Charger** BQ25896: SW → 1 µH as a shape; SYS caps at the inductor; PMID
  cap first, then REGN / BTST caps at their pins (TI layout priorities).
- Every ground pin has its own via to the L2 ground plane; exposed pads have
  their via arrays.

---

## 5. Modem antenna path

Pad 60 → **J302** (Hirose MS-156C3 test switch: a lab cable can be plugged in
here) → **R321** 0 Ω with empty π-match pads C314 / C315 → **J303** u.FL at the
top edge, as on the T-Deck MAX. One straight line on L1, **0.35 mm wide over the
L2 ground plane ≈ 50 Ω** (microstrip, 0.2 mm FR-4 prepreg, εr ≈ 4.4;
Hammerstad formula ≈ 51 Ω before solder mask). Pours keep 0.5 mm away; a row of
ground vias every 1 mm on both sides ("via fence"). No vias in the RF line.

---

## 6. How the copper was routed

The copper was routed by Claude's own router scripts:
a 0.05 mm grid, an A* path search written in C, signals on L1 and L4 only (L1 prefers left–right runs, L4
up–down, so the two layers cross instead of fighting for the same space). The Freerouting autorouter could
not be used here. Order of work:

1. **Fixed copper first:** the power shapes of section 4, the hand-drawn gauge / charger traces, the
   via-in-pad at U103.
2. **Every ground and 3.3 V pin gets its own via** to its plane, right at the pin (347 vias).
3. **Escape stubs** for the fine-pitch pins (QFN, BGA, TSSOP, FPC), and a 3 mm "access corridor" in
   front of each of them that other nets may not use until that pin is connected.
4. **Power trunks** (battery, charger, boost, buck, VBUS, VSYS) at their full width, then their thin
   branches.
5. **The antenna line** on L1 only, no vias.
6. **All signals**, shortest net first.
7. **Rip-up and re-route**, as all-or-nothing transactions: the nets in the way are taken up, the blocked
   net goes first, the others are routed again, and the result is kept only if fewer connections are
   open than before. The last few blocked pins were freed by taking up only the copper within a few mm
   of them (`route_fix.py`).
8. **Ground stitching vias:** a fence on both sides of the antenna line (every 1 mm), a ring along the
   board edge (every 3 mm) and a 4 mm grid elsewhere (580 vias).

**Result:** every connection made (KiCad's own check: 0 unconnected); 7.6 m of track (4.1 m on L1, 3.5 m on L4), 1438 vias (865 of them ground). Smallest track 0.16 mm (only where a trace necks down at a fine-pitch pin); everything else 0.2 mm or wider.

Lessons kept for later boards: most failed connections were pins boxed in by nets routed earlier, so the
fixes were about the space in front of pins (placement keep-out band, corridors, hand-drawn exits, a
pull-up resistor moved, and pin swaps: three I²S pins at the ESP32 in B1-0.3, four keypad-chip inputs in
B1-0.4 — each line now leaves its chip on the side facing where it goes); and a router bug once dropped ~30 vias where traces changed layer, which
KiCad's own connection check caught — every board is now checked by KiCad, not only by the router.

---

## 7. Footprints — where each land pattern comes from

| Part | Source |
|---|---|
| A7670G modem (LCC+LGA 124) | SIMCom *A7672X/A7670X Hardware Design* V1.03 p24 (footprint) / p25 (stencil), pad by pad (user's PDF) |
| SGM6609 boost (TDFN 3×3-12) | SG Micro datasheet REV. A land pattern p16 (user's PDF) |
| Knowles SPU0410LR5H-QB (bottom port) | Knowles data sheet Rev H sheet 6: land pattern + broken-ring stencil; **0.30 mm unplated sound hole**, ring inner Ø opened 0.61 → 0.70 mm (SiSonic Design Guide) |
| Knowles SPU0410HR5H-PB (top port) | Knowles data sheet Rev H sheet 6 |
| Same Sky SJ-43515TS-SMT jack | SJ-4351X-SMT data sheet p2 (user's PDF) |
| Molex 54104-3031 OLED FPC | Molex SD-54104-077 rev C sheet 2 (user's PDF) |
| Everything else | KiCad 7 standard library (IPC-7351 based): Hirose FH12 FPCs, GCT USB4105, Hirose U.FL / MS-156C3, Hirose DM3AT microSD, TI RTW / QFN / BGA packages, chip passives |
| GCT SIM8066 nano-SIM | GCT drawing SIM8066 rev B (05/02/25) sheet 1, "Recommended PCB Layout": 7 contacts, 4 ground tabs, 2 unplated peg holes, and its 7 no-copper areas under the contacts kept free of tracks, vias and pour on the top layer (user's PDF) |

---

## 8. Notes for the board maker

Short version (the package's `README.md` has the full list):

- 4 layers, **1.6 mm**, FR-4, 1 oz outer copper, **ENIG**, green mask both sides, white silkscreen on the
  top only (part labels, block names, the small revision mark); no bottom silkscreen. Some makers print their
  own order number on the board: ask for it on the bottom side (it is empty) or for none.
- Smallest track 0.16 mm, smallest gap 0.15 mm; vias 0.40 / 0.20 mm (1), 0.60 / 0.30 mm (1351), 0.70 / 0.35 mm (81), 0.80 / 0.40 mm (5).
- **One via-in-pad, filled and capped (VIPPO / POFV):** U103 ball B2, 0.40 mm pad / 0.20 mm drill.
  Ask for it at quote time; if a maker cannot do it, the gauge's ground ball needs another solution.
- **One non-plated 0.30 mm hole that must stay open:** MK401's sound port (no plating, no mask, no plug).
- Two locating-peg holes for the nano-SIM (0.75 mm, unplated); USB-C plastic pegs (unplated).
- Top-side assembly only; 17 parts not fitted (listed in the README); test pads, fiducials and
  mounting holes are not in the pick-and-place file.
- No impedance control ordered: the only RF line is 13 mm long; with the usual 0.2 mm prepreg it is ≈ 50 Ω.

---

## 9. Open items before ordering

1. **LUXEON 2835 torch LED (D502) land pattern** — KiCad's generic `LED_PLCC_2835` is used; Lumileds'
   DS383 / AB383 give the recommended pads only as a figure. Check the figure against the footprint
   (or send the PDF and Claude will).
2. **FPC contact sides** — J601 (TFT, Hirose FH12-45S), J602 (OLED, Molex 54104 upper contact, the
   type Newhaven names) and J701 (camera, Hirose FH12-24S): check that each ribbon's contacts face the
   connector's contact side before ordering (a wrong side means a flipped ribbon or another connector).
3. **Camera module pinout** — J701 follows the Adafruit MEMENTO 24-pin order; check the chosen module.
4. **Reviewer's look at the layout** (this package).
5. **Quotes**: ask each turnkey service about the via-in-pad at U103, ENIG, and buying the plug-in parts.

Known KiCad rule-check notes (not errors on the real board): none — the final board has 0 violations and 0 unconnected pads.

---

## 10. Pictures for reviewers

- **01–03: 3D renders** — top at an angle, straight down (same orientation as the layer images; the
  subreddit asks for this one whenever 3D views are posted), and the underside (turned over left-to-right).
  KiCad 7's command line cannot render 3D, so they are made by Claude's own script (`render3d/` in the
  package scripts): `export3d.py` reads every fitted part's place, angle and fab outline from the board;
  `board3d.html` (three.js, run in a headless browser) gives each part a simple body of its package's
  height — grey metal for modules, cans and sockets, ceramic-coloured capacitors with tin ends, black chips
  with leads and a pin-1 dot, beige connectors — and lays the bare-board picture (`render_real.py --bare`)
  on the board's faces. Generic shapes, not the makers' 3D models: good for "what sits where", not for
  exact heights.
- **04–11: the 8 schematic pages**, in colour on white paper (`kicad-cli sch export pdf
  --no-background-color`, 300 dpi).
- **12–16: one copper layer per image** in KiCad's colours (L1 top red, L2 ground plane green, L3 3.3 V
  plane orange, L4 bottom blue) with board edge, holes and silkscreen, then L1 + L4 together.
