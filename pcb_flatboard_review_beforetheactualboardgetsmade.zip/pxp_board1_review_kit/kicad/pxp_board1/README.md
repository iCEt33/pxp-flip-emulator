# PxP board 1 — KiCad project (schematic B1-0.4, layout L1)

Board 1 of a DIY flip phone: a roomy "flat test phone" (160 × 110 mm) with every chip of the phone on one
board plus test points: ESP32-S3-WROOM-1-N16R8, SIMCom A7670G (LTE Cat-1), BQ25896 charger + BQ27220 gauge,
ES8311 codec, TCA8418 keypad chip, PCA9535 expander, TFT / OLED / camera on FPCs, microSD, USB-C.

**Open `pxp_board1.kicad_pro`** in KiCad 7, 8 or 9 (made in KiCad 7; newer versions convert on save).
Schematic and board are in the same project, so cross-probing works.

| File | What |
|---|---|
| `pxp_board1.kicad_sch` + 7 sheets | schematic, 8 pages (overview, power, MCU, modem, audio, keypad/IO, displays, camera) |
| `pxp_board1.kicad_pcb` | the board: 4 layers, 1.6 mm. L1 signals + GND pour · L2 solid GND · L3 solid +3.3 V · L4 signals + GND pour |
| `pxp_board1.kicad_dru` | custom design rules |
| `pxp.kicad_sym`, `pxp.pretty/` | own symbols and footprints (drawn from the makers' datasheets) |

Checks: KiCad DRC 0 violations / 0 unconnected; every pad carries the net the schematic gives it.
Schematic and layout were made with Claude (Anthropic's AI), using its own placement and routing scripts,
then checked in KiCad.

## Known issues (already on the to-do list)

1. **Vias in pads.** About 140 vias sit in or cut into soldered pads (the router allowed same-net vias in
   pads, and KiCad's DRC does not flag that). Plan: move them off the pads, or order all vias filled and
   capped. U103's centre ball (B2) is meant to be a filled and capped via-in-pad.
2. **L4 signals reference the +3.3 V plane (L3), not ground.** Plan: at least move the analog audio
   (microphone) lines to L1 over the ground plane; or make L3 a second ground plane. Advice welcome.

Any other comments are very welcome. Thanks for looking!
